userConfig=[
{
        "user":"bzwjyydqfp@rambler.ru",
        "password":"aaaaaa",
        "image":r"F:\pythonProject\aws_influncer\send.jpg",
        # "content":"Dear Amazon Seller,  "
    },
{
        "user":"tjsqytwffz@rambler.ru",
        "password":"aaaaaa",
        "image":r"F:\pythonProject\aws_influncer\send.jpg",
        # "content":"Hello Amazon Seller,"
     },
{
        "user":"ctktekmxck@rambler.ru",
        "password":"aaaaaa",
        "image":r"F:\pythonProject\aws_influncer\send.jpg",
        # "content":"Dear Amazon Seller,  "
    },
# {
#         "user":"qfbaxbixpg@rambler.ru",
#         "password":"aaaaaa",
#         "image":r"F:\pythonProject\aws_influncer\send.jpg",
#         # "content":"Hello Amazon Seller,"
#      },
{
        "user":"gxqnsoxggr@rambler.ru",
        "password":"aaaaaa",
        "image":r"F:\pythonProject\aws_influncer\send.jpg",
        # "content":"Dear Amazon Seller,  "
    },
# {
#         "user":"ydkozuemph@rambler.ru",
#         "password":"aaaaaa",
#         "image":r"F:\pythonProject\aws_influncer\send.jpg",
#         # "content":"Hello Amazon Seller,"
#      },
{
        "user":"vevtmyyfii@rambler.ru",
        "password":"aaaaaa",
        "image":r"F:\pythonProject\aws_influncer\send.jpg",
        # "content":"Dear Amazon Seller,  "
    },
{
        "user":"ouqxrltzlh@rambler.ru",
        "password":"aaaaaa",
        "image":r"F:\pythonProject\aws_influncer\send.jpg",
        # "content":"Hello Amazon Seller,"
     },
{
        "user":"dgdzjxcqjx@rambler.ru",
        "password":"aaaaaa",
        "image":r"F:\pythonProject\aws_influncer\send.jpg",
        # "content":"Hello Amazon Seller,"
     },
{
        "user":"zcxndbxmdc@rambler.ru",
        "password":"aaaaaa",
        "image":r"F:\pythonProject\aws_influncer\send.jpg",
        # "content":"Hello Amazon Seller,"
     },
{
        "user":"rgoxoeijoa@rambler.ru",
        "password":"aaaaaa",
        "image":r"F:\pythonProject\aws_influncer\send.jpg",
        # "content":"Hello Amazon Seller,"
     },

]
config=[
    "B09HC51L11",
    "B07N7PK9QK",
    "B0014C2NBC",
    "B07HQPKDZB",
    "B09CGP2WMW",
    "B08VNH5L6Y",
    "B0BB9969MN",
    "B07SFSTHL9",
    "B092LPWXMM",
    "B0779V6BC4",
    "B08NX5CFV5",
    "B0765B38QV",
    "B0825CPQ8H",
    "B0BN132KYP",
    "B0865WF6NY",
    "B003979KMU",
    "B00WRMKUIG",
    "B07WSJVTR9",
    "B08PKFHCMS",
    "B0B6PR8G2V",
    "B09HC51L11",
    "B07N7PK9QK",
    "B0014C2NBC",
    "B07HQPKDZB",
    "B09CGP2WMW",
    "B08VNH5L6Y",
    "B0BB9969MN",
    "B07SFSTHL9",
    "B092LPWXMM",
    "B0779V6BC4",
    "B08NX5CFV5",
    "B0B4SMPNDP",
    "B07ZQQ2BBP",
    "B08D8TTNH5",
    "B09WGXTP4Y",
    "B089QCSBXJ",
    "B07MZXF1C3",
    "B07DPRVSCR",
    "B081W2S2QY",
    "B0B5Z6D818"
]