userConfig=[
{
        "user":"tjsqytwffz@rambler.ru",
        "password":"aaaaaa",
        "image":r"F:\pythonProject\aws_influncer\send.jpg",
        # "content":"Hello Amazon Seller,"
     },
    {
        "user":"bzwjyydqfp@rambler.ru",
        "password":"aaaaaa",
        "image":r"F:\pythonProject\aws_influncer\send.jpg",
        # "content":"Dear Amazon Seller,  "
    }
]
keysArr=[]
