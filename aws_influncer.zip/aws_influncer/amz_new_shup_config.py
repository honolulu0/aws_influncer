type =[
    "https://www.amazon.com/Best-Sellers-Electronics-Video-Projectors/zgbs/electronics/300334/ref=zg_bs_nav_electronics_1",
"https://www.amazon.com/Best-Sellers-Kitchen-Dining-Centrifugal-Juicers/zgbs/kitchen/7223586011/ref=zg_bs_nav_kitchen_3_289926",
"https://www.amazon.com/Best-Sellers-Electronics-Bookshelf-Speakers/zgbs/electronics/3236451011/ref=zg_bs_nav_electronics_3_172563",
"https://www.amazon.com/Best-Sellers-Patio-Lawn-Garden-Outdoor-Power-Lawn-Equipment/zgbs/lawn-garden/551242/ref=zg_bs_nav_lawn-garden_1",
"https://www.amazon.com/best-sellers-camera-photo/zgbs/photo/ref=zg_bs_nav_0",
"https://www.amazon.com/Best-Sellers-Appliances/zgbs/appliances/ref=zg_bs_nav_0",
"https://www.amazon.com/gp/bestsellers/home-garden/510110/ref=pd_zg_hrsr_home-garden",
"https://www.amazon.com/gp/bestsellers/lawn-garden/4543152011/ref=pd_zg_hrsr_lawn-garden",
"https://www.amazon.com/gp/bestsellers/home-garden/510192/ref=pd_zg_hrsr_home-garden",
"https://www.amazon.com/Best-Sellers-Patio-Lawn-Garden-Garden-Miniatures/zgbs/lawn-garden/17595813011/ref=zg_bs_nav_lawn-garden_3_553802",
"https://www.amazon.com/gp/bestsellers/hi/553402/ref=pd_zg_hrsr_hi"
]
